# 鲁港通 - 发现层（spec 第 8 节）：从各发现端点提取候选 URL。
# 所有解析器只做"提取"，不做网络请求、不做白名单校验（校验统一在 pipeline）。
from __future__ import annotations

import re
from dataclasses import dataclass
from html.parser import HTMLParser
from urllib.parse import urljoin, urlsplit


@dataclass(frozen=True)
class DiscoveredItem:
    """一个候选链接及其可选元信息（RSS 条目带标题/发布时间）。"""

    url: str
    title: str | None = None
    published: str | None = None


# ---------------------------------------------------------------------------
# RSS / Atom（news.gov.hk topstories、data.gov.hk 每日更新源）
# ---------------------------------------------------------------------------

def parse_rss(content: bytes) -> list[DiscoveredItem]:
    """解析 RSS 2.0 / Atom，返回条目链接（feedparser 自动处理格式差异）。"""
    import feedparser

    feed = feedparser.parse(content)
    items: list[DiscoveredItem] = []
    for entry in feed.entries:
        link = entry.get("link")
        if not link:
            continue
        items.append(
            DiscoveredItem(
                url=link.strip(),
                title=(entry.get("title") or "").strip() or None,
                published=entry.get("published") or entry.get("updated"),
            )
        )
    return items


# ---------------------------------------------------------------------------
# sitemap.xml（investhk 4787 / edb 15497 / hkma 3.8MB；支持 sitemapindex 嵌套引用）
# ---------------------------------------------------------------------------

_SITEMAP_NS = "{http://www.sitemaps.org/schemas/sitemap/0.9}"


def parse_sitemap(content: bytes, base_url: str) -> list[DiscoveredItem]:
    """解析 sitemap.xml / sitemapindex（index 只返回子 sitemap URL，由 pipeline 递归拉取）。"""
    import xml.etree.ElementTree as ET

    try:
        root = ET.fromstring(content)
    except ET.ParseError:
        return []

    items: list[DiscoveredItem] = []
    # 鲁港通 - sitemapindex：loc 指向子 sitemap，同样返回（pipeline 会继续拉取解析）
    for loc in root.iter(f"{_SITEMAP_NS}loc"):
        url = (loc.text or "").strip()
        if url:
            items.append(DiscoveredItem(url=urljoin(base_url, url)))
    return items


def is_sitemap(content_type: str, content: bytes) -> bool:
    """判断响应是否为 sitemap（content-type 不可靠时嗅探根元素）。"""
    ct = (content_type or "").split(";", 1)[0].strip().lower()
    if ct in ("application/xml", "text/xml", "application/rss+xml", "application/atom+xml"):
        return True
    head = content[:512].lstrip()
    return head.startswith(b"<") and (b"<urlset" in head or b"<sitemapindex" in head)


# ---------------------------------------------------------------------------
# listing / 栏目页（info.gov.hk 公报列表、山东厅局首页、jinan /col/colXXX/）
# ---------------------------------------------------------------------------

class _LinkCollector(HTMLParser):
    """提取 <a href>；忽略锚点/javascript/data 链接。

    鲁港通 - 不再采集同页 <title>：实测山东政务站栏目页/首页的 <title> 是站点名
    （如「山东省商务厅」），把它当作发现项标题会让所有文章标题退化成站点名。
    文章标题统一由 extract 从文章页自身提取。
    """

    _SKIP_SCHEMES = ("javascript:", "mailto:", "tel:", "data:")

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.links: list[str] = []

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag == "a":
            href = dict(attrs).get("href")
            if href:
                self.links.append(href.strip())


def parse_listing(content: bytes, base_url: str, *, max_links: int = 500) -> list[DiscoveredItem]:
    """从列表页 HTML 提取链接（相对地址基于 base_url 拼接；上限防超大门户页）。

    返回项不带 title（入口页标题不代表文章标题），由 pipeline 抓取文章页后提取。
    """
    collector = _LinkCollector()
    try:
        collector.feed(_decode_html(content))
    except Exception:  # noqa: BLE001 - 政府站编码混杂，解析失败按 0 链接处理
        return []

    items: list[DiscoveredItem] = []
    seen: set[str] = set()
    for href in collector.links:
        if href.lower().startswith(_LinkCollector._SKIP_SCHEMES):
            continue
        absolute = urljoin(base_url, href)
        # 鲁港通 - 去掉 fragment（#xxx 不产生新内容）并去重
        absolute = absolute.split("#", 1)[0]
        if absolute and absolute not in seen:
            seen.add(absolute)
            items.append(DiscoveredItem(url=absolute))
        if len(items) >= max_links:
            break
    return items


# 鲁港通 - 栏目/列表/分页页形态黑名单（实测取证 2026-09-09，diag-colpages.log + probe-cols.log）：
# 两类形态：① 路径末段是 index.html / index_N.html（栏目页与翻页）；
# ② 路径正好终止于 /col/colNNNNN/（不带 index.html 的栏目页）。
# 第②类必须带 $ 锚点：实测济南市系（政府集约化平台）的文章页就嵌在栏目路径下，
# 形如 /col/col18309/art/2026/art_60aea502...html，若不加锚点会把 jinan_gov/jinan_hrss
# 的文章页全部误杀（一篇也采不到）；省级厅局文章页则是 /art/2026/8/25/art_10579_xxx.html。
# 用黑名单而非白名单：港府文章页形态各异且大量无扩展名（/eng/e-visa.html、
# /en/our-clients/<slug>/、/gia/general/202609/09/P2026090900732.htm），白名单会误杀。
_LISTING_PAGE_RE = re.compile(r"/index(?:_\d+)?\.s?html?$|/col/col\d+/$", re.IGNORECASE)

# 政务云 CMS 的栏目路径前缀（单独不足以判定列表页，需与 _LISTING_PAGE_RE 同时命中）
_COLUMN_PATH_RE = re.compile(r"/col/col\d+(?:/|$)", re.IGNORECASE)


def is_listing_page(url: str) -> bool:
    """判定 URL 是否为栏目/列表/分页页（不是可入库的文档页）。

    只按路径形态判定，不看内容：栏目页正文容器里是链接标题堆叠，实测 282~1930 字，
    足以越过 MIN_CONTENT_CHARS 入库门槛，必须在抓取前就挡掉。
    """
    return bool(_LISTING_PAGE_RE.search(urlsplit(url).path))


def is_column_page(url: str) -> bool:
    """是否为政务云 CMS 的栏目页（/col/colNNNNN/index.html）。

    必须同时满足「在 /col/ 栏目路径下」与「末段是 index 页」：实测济南市系的
    文章页也在 /col/ 下（/col/col18309/art/2026/art_<uuid>.html），只看 /col/ 会误杀。
    """
    path = urlsplit(url).path
    return bool(_COLUMN_PATH_RE.search(path)) and bool(_LISTING_PAGE_RE.search(path))


def _decode_html(content: bytes) -> str:
    """按 meta charset 或 BOM 解码 HTML（GB18030/UTF-8/BIG5 混杂是政务站常态）。

    鲁港通 - gb18030 必须单独列出：它是 gb2312/gbk 的超集，部分山东政务站直接声明
    charset=gb18030，若不识别就会退化成 UTF-8 解码得到乱码（正文入库与锚文本匹配双失败）。
    """
    if content.startswith(b"\xef\xbb\xbf"):
        return content.decode("utf-8-sig", errors="replace")
    head = content[:2048]
    for enc in (b"utf-8", b"UTF-8", b"gb18030", b"GB18030", b"gbk", b"GBK",
                b"gb2312", b"GB2312", b"big5", b"BIG5"):
        if enc in head:
            try:
                return content.decode(enc.decode("ascii"), errors="replace")
            except LookupError:
                break
    return content.decode("utf-8", errors="replace")


# ---------------------------------------------------------------------------
# fixed_url（施政报告等固定页：直接返回自身）
# ---------------------------------------------------------------------------

def parse_fixed(urls: list[str]) -> list[DiscoveredItem]:
    return [DiscoveredItem(url=u) for u in urls]
