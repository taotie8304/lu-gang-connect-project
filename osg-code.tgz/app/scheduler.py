# 鲁港通 - OSG 定时调度（spec 第 12 节）：APScheduler 按 source.schedule_cron
# 周期触发同步。串行执行（与手动触发共用互斥锁），同一来源上一轮未结束则跳过本轮。
from __future__ import annotations

import logging

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy import select

logger = logging.getLogger("lugang.osg.scheduler")

_scheduler: BackgroundScheduler | None = None


def start_scheduler(app) -> None:
    """启动后台调度（FastAPI lifespan 调用）。加载 DB 中全部 enabled 且有 cron 的来源。"""
    global _scheduler
    if _scheduler is not None:
        return

    from app.database import SessionLocal
    from app.ingest.pipeline import sync_source
    from app.models import Source

    scheduler = BackgroundScheduler(timezone="Asia/Hong_Kong")

    session = SessionLocal()
    try:
        sources = session.execute(
            select(Source).where(Source.enabled.is_(True), Source.schedule_cron.isnot(None))
        ).scalars().all()
        for src in sources:
            job_id = f"sync_{src.code}"
            scheduler.add_job(
                _make_job(src.code),
                CronTrigger.from_crontab(src.schedule_cron),
                id=job_id,
                name=job_id,
                max_instances=1,        # 鲁港通 - 上一轮没跑完不再叠加
                coalesce=True,          # 错过的多次触发合并为一次
                misfire_grace_time=3600,
            )
    finally:
        session.close()

    scheduler.start()
    _scheduler = scheduler
    logger.info("scheduler started with %d jobs", len(scheduler.get_jobs()))


def shutdown_scheduler() -> None:
    global _scheduler
    if _scheduler is not None:
        _scheduler.shutdown(wait=False)
        _scheduler = None


def _make_job(code: str):
    """构造一个来源的同步 job（独立会话 + 锁，与手动触发互斥）。"""
    import threading

    from app.database import SessionLocal
    from app.ingest.pipeline import sync_source
    from app.models import Source
    from app.api.admin import _sync_lock

    def _run():
        if _sync_lock.locked():
            logger.info("skip scheduled sync %s: manual sync in progress", code)
            return
        with _sync_lock:
            session = SessionLocal()
            try:
                src = session.execute(
                    select(Source).where(Source.code == code)
                ).scalar_one_or_none()
                if src is None or not src.enabled:
                    return
                sync_source(session, src)
            finally:
                session.close()

    return _run
