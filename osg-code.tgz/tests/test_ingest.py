# 鲁港通 - Phase 2 测试：yaml 导入 / 发现层解析 / 内容提取 / pipeline 全流程
# 全部离线（SQLite 内存库 + 假 fetcher），不发真实网络请求。
from __future__ import annotations

import pytest
from sqlalchemy import select

from app.config import Settings
from app.database import Base
from app.ingest.discover import is_listing_page, parse_listing, parse_rss, parse_sitemap
from app.ingest.extract import MIN_CONTENT_CHARS, clean_title, extract_html
from app.ingest.pipeline import sync_source
from app.ingest.yaml_import import import_sources_yaml
from app.models import CrawlRun, CrawlTask, Document, DocumentVersion, Source, SourceDomainRule
from app.security.fetcher import FetchResult

# 鲁港通 - db fixture 已上移 tests/conftest.py（探测工具测试共用）


MINI_YAML = """
sources:
  - id: hk_news_test
    name: 测试新闻网
    group: hk_core_gov
    organization: 测试机构
    base_domains: [www.news.gov.hk]
    allowed_path_prefixes: [/en/]
    discovery_method: rss
    feed_urls:
      - https://www.news.gov.hk/en/common/html/topstories.rss.xml
    schedule: "0 */6 * * *"
    rate_limit_per_minute: 6
    enabled: true
  - id: sd_test
    name: 测试山东厅
    group: sd_core_gov
    organization: 山东省商务厅
    base_domains: [commerce.shandong.gov.cn]
    allowed_path_prefixes: [/]
    allow_http: true
    force_ipv4: true
    discovery_method: listing
    listing_urls:
      - http://commerce.shandong.gov.cn/
    enabled: true
"""


# ---------------------------------------------------------------------------
# yaml 导入器
# ---------------------------------------------------------------------------

class TestYamlImport:
    def test_import_creates_sources_and_rules(self, db):
        result = import_sources_yaml(MINI_YAML, db)
        assert result.imported == ["hk_news_test", "sd_test"]
        assert not result.errors

        src = db.execute(select(Source).where(Source.code == "hk_news_test")).scalar_one()
        assert src.discovery_method == "rss"
        assert src.allow_http is False
        assert src.discovery_config["feed_urls"]

        rules = db.execute(
            select(SourceDomainRule).where(SourceDomainRule.source_id == src.id)
        ).scalars().all()
        assert len(rules) == 1
        assert rules[0].hostname == "www.news.gov.hk"
        assert rules[0].path_prefix == "/en/"
        assert rules[0].allow_http is False

    def test_import_idempotent_and_http_flag(self, db):
        import_sources_yaml(MINI_YAML, db)
        result = import_sources_yaml(MINI_YAML, db)
        # 第二次导入全部是 update，不新增
        assert result.imported == []
        assert set(result.updated) == {"hk_news_test", "sd_test"}
        assert db.execute(select(Source)).scalars().all().__len__() == 2

        sd = db.execute(select(Source).where(Source.code == "sd_test")).scalar_one()
        assert sd.allow_http is True and sd.force_ipv4 is True
        sd_rules = db.execute(
            select(SourceDomainRule).where(SourceDomainRule.source_id == sd.id)
        ).scalars().all()
        assert all(r.allow_http for r in sd_rules)

    def test_import_bad_yaml_rejected(self, db):
        with pytest.raises(ValueError):
            import_sources_yaml("not_a_mapping: [", db)


# ---------------------------------------------------------------------------
# 发现层解析器
# ---------------------------------------------------------------------------

RSS_SAMPLE = """<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0"><channel><title>T</title>
<item><title>香港新闻一</title><link>https://www.news.gov.hk/en/2026/09/1.html</link>
<pubDate>Wed, 09 Sep 2026 08:00:00 GMT</pubDate></item>
<item><title>香港新闻二</title><link>https://www.news.gov.hk/en/2026/09/2.html</link></item>
</channel></rss>""".encode("utf-8")

SITEMAP_SAMPLE = b"""<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<url><loc>https://www.investhk.gov.hk/en/page-a</loc></url>
<url><loc>https://www.investhk.gov.hk/en/page-b</loc></url>
</urlset>"""

SITEMAPINDEX_SAMPLE = b"""<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
<sitemap><loc>https://www.edb.gov.hk/sitemap-pages.xml</loc></sitemap>
</sitemapindex>"""

LISTING_SAMPLE = (
    b"<html><head><meta charset='utf-8'><title>\xe5\xb1\xb1\xe4\xb8\x9c\xe6\x94\xbf\xe5\x8a\xa1</title></head>"
    b"<body><a href='/col/col1234/index.html'>col</a>"
    b"<a href='https://other.example.com/x'>out</a>"
    b"<a href='javascript:void(0)'>js</a>"
    b"<a href='/art/2026/1.html#frag'>art</a></body></html>"
)


class TestDiscover:
    def test_parse_rss(self):
        items = parse_rss(RSS_SAMPLE)
        assert len(items) == 2
        assert items[0].url.endswith("/1.html")
        assert items[0].title == "香港新闻一"
        assert items[0].published is not None

    def test_parse_sitemap(self):
        items = parse_sitemap(SITEMAP_SAMPLE, "https://www.investhk.gov.hk/sitemap.xml")
        assert {i.url for i in items} == {
            "https://www.investhk.gov.hk/en/page-a",
            "https://www.investhk.gov.hk/en/page-b",
        }

    def test_parse_sitemapindex(self):
        items = parse_sitemap(SITEMAPINDEX_SAMPLE, "https://www.edb.gov.hk/sitemap.xml")
        assert items[0].url == "https://www.edb.gov.hk/sitemap-pages.xml"

    def test_parse_listing_links_and_dedupe(self):
        items = parse_listing(LISTING_SAMPLE, "http://commerce.shandong.gov.cn/")
        urls = [i.url for i in items]
        assert "http://commerce.shandong.gov.cn/col/col1234/index.html" in urls
        assert "http://commerce.shandong.gov.cn/art/2026/1.html" in urls
        # javascript 链接剔除；外链保留（白名单过滤是 pipeline 职责）
        assert all(not u.startswith("javascript") for u in urls)
        assert "https://other.example.com/x" in urls
        # 鲁港通 - 入口页标题不再传播（实测站点名会让文章标题全部退化）
        assert all(i.title is None for i in items)

    def test_parse_listing_gbk_encoding(self):
        gbk_html = "<html><head><meta charset='gbk'><title>山东</title></head><body><a href='/a'>x</a></body></html>".encode("gbk")
        items = parse_listing(gbk_html, "http://tjj.shandong.gov.cn/")
        # GBK 解码后仍能提取链接（中文 href/文本不乱码）
        assert items[0].url == "http://tjj.shandong.gov.cn/a"


# ---------------------------------------------------------------------------
# 内容提取
# ---------------------------------------------------------------------------

class TestExtract:
    def test_extract_html_title_and_text(self):
        html = (
            b"<html><head><title>Test Page</title></head><body>"
            b"<script>var x=1;</script><style>.a{}</style>"
            b"<p>Hello paragraph</p><div>Second line</div></body></html>"
        )
        out = extract_html(html)
        assert out.title == "Test Page"
        assert "Hello paragraph" in out.text
        assert "Second line" in out.text
        assert "var x=1" not in out.text   # script 剔除
        assert out.language_hint == "en"

    def test_extract_html_lang_hint(self):
        html = "<html><head><title>香港特別行政區政府</title></head><body><p>政府新聞公報</p></body></html>".encode()
        out = extract_html(html)
        assert out.language_hint == "zh-Hant"


# ---------------------------------------------------------------------------
# pipeline 全流程（假 fetcher）
# ---------------------------------------------------------------------------

# 鲁港通 - pipeline 有 MIN_CONTENT_CHARS 正文门槛（实测栏目页 28~59 字、文章页 900+ 字），
# 测试样本必须模拟真实文章长度，否则会被噪声页过滤挡掉。
_LONG_EN = (
    "The Government announced today that the Belt and Road Summit concluded successfully. "
    "Over fifty delegations attended the two-day event to discuss infrastructure investment, "
    "financial cooperation and professional services. The Chief Executive highlighted that "
    "Hong Kong enjoys unique advantages under the one country, two systems framework, including "
    "a common law legal system, free flow of capital and information, and a deep pool of "
    "international talent. She emphasised that continued national support is the strongest "
    "backing for the long-term prosperity and stability of the city."
)
_LONG_ZH = (
    "省商务厅今日发布通知，为深入推进鲁港经贸合作，进一步扩大双向投资规模，现就有关事项"
    "通知如下。一、加强产业对接，聚焦高端装备、现代海洋、医养健康等重点领域，组织企业赴港"
    "开展精准对接活动。二、优化营商环境，落实外商投资准入前国民待遇加负面清单管理制度，"
    "依法保护投资者合法权益。三、强化服务保障，建立重点外资项目服务专员制度，及时协调解决"
    "项目落地过程中的困难和问题。四、各地商务主管部门要切实履行职责，加强组织领导，确保各项"
    "措施落到实处，推动全省商务工作高质量发展。"
)


def _article_html(title: str, body: str) -> bytes:
    """构造一篇达标的测试文章页（正文长度超过噪声页门槛）。"""
    return (
        f"<html><head><title>{title}</title></head><body><p>{body}</p></body></html>"
    ).encode("utf-8")


def _mk_settings(**kw) -> Settings:
    return Settings(api_key_fastgpt="x", source_min_interval_s=0, **kw)


# 鲁港通 - 测试用假 DNS：白名单域名一律解析到公网 IP，不碰真实网络
_FAKE_IPS = {"www.news.gov.hk": "203.198.135.1", "commerce.shandong.gov.cn": "218.98.19.1"}


def fake_resolver(hostname: str) -> tuple[str, ...]:
    return (_FAKE_IPS.get(hostname, "203.198.135.1"),)


def _mk_fetch_result(url: str, body: bytes, content_type: str = "text/html") -> FetchResult:
    return FetchResult(
        final_url=url, http_status=200, content_type=content_type, content=body
    )


class _FakeFetcher:
    """按 URL 返回预置响应；未预置的 URL 抛网络异常。"""

    def __init__(self, responses: dict[str, bytes]):
        self.responses = responses
        self.calls: list[str] = []

    def __call__(self, url, rules, settings):
        self.calls.append(url)
        if url in self.responses:
            return _mk_fetch_result(url, self.responses[url])
        raise ConnectionError(f"no route to {url}")


class TestPipeline:
    def _setup_source(self, db, code="hk_news_test"):
        import_sources_yaml(MINI_YAML, db)
        return db.execute(select(Source).where(Source.code == code)).scalar_one()

    def test_rss_sync_full_flow(self, db):
        src = self._setup_source(db)
        article = _article_html("HK News A", _LONG_EN)
        fetcher = _FakeFetcher({
            "https://www.news.gov.hk/en/common/html/topstories.rss.xml": RSS_SAMPLE,
            "https://www.news.gov.hk/en/2026/09/1.html": article,
            "https://www.news.gov.hk/en/2026/09/2.html": article,
        })

        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)

        # 发现 2 条 → 白名单校验通过 → 全部入库
        assert stats.discovered == 2
        assert stats.new_docs == 2
        assert stats.rejected == 0

        docs = db.execute(select(Document)).scalars().all()
        assert len(docs) == 2
        assert all(d.status == "candidate" for d in docs)
        versions = db.execute(select(DocumentVersion)).scalars().all()
        assert len(versions) == 2
        assert versions[0].extracted_text and "Belt and Road Summit" in versions[0].extracted_text

        run = db.execute(select(CrawlRun)).scalar_one()
        assert run.status == "finished"
        assert run.new_docs == 2

        tasks = db.execute(select(CrawlTask)).scalars().all()
        assert all(t.status == "new" for t in tasks)

    def test_second_sync_unchanged(self, db):
        src = self._setup_source(db)
        article = _article_html("HK News A", _LONG_EN)
        fetcher = _FakeFetcher({
            "https://www.news.gov.hk/en/common/html/topstories.rss.xml": RSS_SAMPLE,
            "https://www.news.gov.hk/en/2026/09/1.html": article,
            "https://www.news.gov.hk/en/2026/09/2.html": article,
        })
        sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                    sleeper=lambda s: None, resolver=fake_resolver)

        # 第二次同步（默认不 force）：已知文档直接跳过，不重抓
        stats2 = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                             sleeper=lambda s: None, resolver=fake_resolver)
        assert stats2.already_known == 2
        assert stats2.new_docs == 0

        # force 重抓：内容未变 → unchanged，不建新版本
        stats3 = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                             sleeper=lambda s: None, resolver=fake_resolver, force_refetch=True)
        assert stats3.unchanged_docs == 2
        assert db.execute(select(DocumentVersion)).scalars().all().__len__() == 2

    def test_content_change_creates_new_version(self, db):
        src = self._setup_source(db)
        v1 = _article_html("A", _LONG_EN)
        fetcher = _FakeFetcher({
            "https://www.news.gov.hk/en/common/html/topstories.rss.xml": RSS_SAMPLE,
            "https://www.news.gov.hk/en/2026/09/1.html": v1,
            "https://www.news.gov.hk/en/2026/09/2.html": v1,
        })
        sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                    sleeper=lambda s: None, resolver=fake_resolver)

        v2 = _article_html("A", _LONG_EN + " Updated paragraph appended.")
        fetcher.responses["https://www.news.gov.hk/en/2026/09/1.html"] = v2
        stats2 = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                             sleeper=lambda s: None, resolver=fake_resolver, force_refetch=True)

        assert stats2.updated_docs == 1
        assert stats2.unchanged_docs == 1
        assert db.execute(select(DocumentVersion)).scalars().all().__len__() == 3

        doc = db.execute(
            select(Document).where(Document.canonical_url.endswith("1.html"))
        ).scalar_one()
        # latest_version_id 指向新版本，旧版本 is_current=False
        current = db.execute(
            select(DocumentVersion).where(DocumentVersion.id == doc.latest_version_id)
        ).scalar_one()
        assert "Updated paragraph appended" in current.extracted_text

    def test_non_allowlist_url_rejected_in_pipeline(self, db):
        # RSS 条目里混入白名单外链接 → pipeline 记 rejected，不抓取
        mixed_rss = RSS_SAMPLE.replace(
            b"https://www.news.gov.hk/en/2026/09/2.html",
            b"https://evil.example.com/steal",
        )
        src = self._setup_source(db)
        article = _article_html("ok", _LONG_EN)
        fetcher = _FakeFetcher({
            "https://www.news.gov.hk/en/common/html/topstories.rss.xml": mixed_rss,
            "https://www.news.gov.hk/en/2026/09/1.html": article,
        })
        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)
        assert stats.rejected == 1
        assert stats.new_docs == 1
        assert "https://evil.example.com/steal" not in fetcher.calls

        rejected_task = db.execute(
            select(CrawlTask).where(CrawlTask.reject_reason.isnot(None))
        ).scalar_one()
        assert rejected_task.reject_reason == "NOT_IN_ALLOWLIST"

    def test_http_allowed_for_shandong_source(self, db):
        # 山东来源 allow_http=True：http URL 校验通过并可抓取
        src = self._setup_source(db, code="sd_test")
        listing = (
            "<html><head><meta charset='utf-8'><title>商务厅</title></head>"
            "<body><a href='/art/2026/policy.html'>p</a></body></html>"
        ).encode("utf-8")
        # 鲁港通 - 实测山东政务站 <title> 格式：站点名 + 栏目名 + 文章标题
        article = _article_html("山东省商务厅 商务要闻 关于商务厅设立驻港办事处的通知", _LONG_ZH)
        fetcher = _FakeFetcher({
            "http://commerce.shandong.gov.cn/": listing,
            "http://commerce.shandong.gov.cn/art/2026/policy.html": article,
        })
        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)
        assert stats.new_docs == 1
        doc = db.execute(select(Document)).scalar_one()
        assert doc.language == "zh-Hans"
        # 标题清洗：去掉站点名与栏目名前缀，保留真实文章标题
        assert doc.title == "关于商务厅设立驻港办事处的通知"

    def test_fetch_failure_retried_then_recorded(self, db):
        src = self._setup_source(db)
        fetcher = _FakeFetcher({
            "https://www.news.gov.hk/en/common/html/topstories.rss.xml": RSS_SAMPLE,
        })
        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)
        # 详情页不可达：重试 2 次后记 failed；run 正常 finished
        assert stats.fetch_failed == 2
        assert stats.discovered == 2
        run = db.execute(select(CrawlRun)).scalar_one()
        assert run.status == "finished"
        # 每个失败 URL 调用 3 次（初次+2 重试）
        assert fetcher.calls.count("https://www.news.gov.hk/en/2026/09/1.html") == 3

    # ------------------------------------------------------------------
    # 鲁港通 - 噪声页过滤（服务器首轮采集实测发现的两类污染）
    # ------------------------------------------------------------------

    def test_entry_page_itself_skipped(self, db):
        """列表页里指向自身的链接（首页导航常见）不得当文档入库。"""
        src = self._setup_source(db, code="sd_test")
        listing = (
            "<html><head><meta charset='utf-8'><title>山东省商务厅</title></head><body>"
            "<a href='http://commerce.shandong.gov.cn/'>首页</a>"
            "<a href='/art/2026/a.html'>文章</a></body></html>"
        ).encode("utf-8")
        fetcher = _FakeFetcher({
            "http://commerce.shandong.gov.cn/": listing,
            "http://commerce.shandong.gov.cn/art/2026/a.html": _article_html(
                "山东省商务厅 商务要闻 省商务厅召开创建全国文明单位工作推进会", _LONG_ZH
            ),
        })
        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)
        assert stats.new_docs == 1      # 只有文章页入库
        tasks = {t.url: t.status for t in db.execute(select(CrawlTask)).scalars()}
        assert tasks["http://commerce.shandong.gov.cn/"] == "skipped_entry"

    def test_listing_page_filtered_by_shape_before_fetch(self, db):
        """栏目/分页页按 URL 形态在抓取前挡掉。

        鲁港通 - 实测取证（diag-colpages.log）：山东政务云栏目页的正文容器里是链接
        标题堆叠，282~1930 字，足以越过 MIN_CONTENT_CHARS 入库（sd_czt 首轮 9 篇混进
        5 篇），故只能靠形态过滤；本例故意把栏目页正文做得很长，证明拦下它的不是字数门槛。
        """
        src = self._setup_source(db, code="sd_test")
        listing = (
            "<html><body><a href='/col/col1234/index.html'>通知公告</a>"
            "<a href='/col/col1234/index_1.html'>下一页</a>"
            "<a href='/art/2026/a.html'>文章</a></body></html>"
        ).encode("utf-8")
        col_page = _article_html("山东省商务厅 通知公告", _LONG_ZH * 3)   # 正文远超门槛
        fetcher = _FakeFetcher({
            "http://commerce.shandong.gov.cn/": listing,
            "http://commerce.shandong.gov.cn/col/col1234/index.html": col_page,
            "http://commerce.shandong.gov.cn/col/col1234/index_1.html": col_page,
            "http://commerce.shandong.gov.cn/art/2026/a.html": _article_html(
                "山东省商务厅 商务要闻 全省商务工作会议在济南召开", _LONG_ZH
            ),
        })
        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)
        assert stats.new_docs == 1
        assert stats.skipped_non_article == 2
        tasks = {t.url: t.status for t in db.execute(select(CrawlTask)).scalars()}
        assert tasks["http://commerce.shandong.gov.cn/col/col1234/index.html"] == "skipped_non_article"
        assert tasks["http://commerce.shandong.gov.cn/col/col1234/index_1.html"] == "skipped_non_article"
        # 栏目页连抓取都不应发生：既省配额也省请求
        assert not any("/col/" in u for u in fetcher.calls)
        assert db.execute(
            select(Document).where(Document.canonical_url.like("%/col/%"))
        ).scalar_one_or_none() is None

    def test_fixed_url_source_exempt_from_shape_filter(self, db):
        """fixed_url 的入口就是目标文档：即使形态像列表页也绝不过滤。"""
        src = self._setup_source(db, code="sd_test")
        src.discovery_method = "fixed_url"
        src.discovery_config = {
            "fixed_urls": ["http://commerce.shandong.gov.cn/col/col1234/index.html"]
        }
        db.commit()
        fetcher = _FakeFetcher({
            "http://commerce.shandong.gov.cn/col/col1234/index.html": _article_html(
                "山东省商务厅 施政报告全文", _LONG_ZH
            ),
        })
        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)
        assert stats.skipped_non_article == 0
        assert stats.new_docs == 1

    def test_limit_reached_stops_creating_tasks(self, db):
        """达到单轮上限后立即结束，不再为剩余候选逐条建 crawl_task。

        鲁港通 - 实测 hk_investhk 的 sitemap 有 4787 条 URL，采满 100 篇上限后仍逐条
        建了 4600+ 行 skipped_limit 并逐行 commit，白耗十几分钟且全程占着全局同步锁。
        """
        src = self._setup_source(db, code="sd_test")
        src.max_pages_per_run = 1
        db.commit()
        listing = (
            "<html><body>"
            + "".join(f"<a href='/art/2026/{i}.html'>a{i}</a>" for i in range(6))
            + "</body></html>"
        ).encode("utf-8")
        responses = {"http://commerce.shandong.gov.cn/": listing}
        for i in range(6):
            responses[f"http://commerce.shandong.gov.cn/art/2026/{i}.html"] = _article_html(
                "山东省商务厅 商务要闻 测试文章", _LONG_ZH
            )
        fetcher = _FakeFetcher(responses)
        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)
        assert stats.discovered == 6
        assert stats.new_docs == 1
        assert stats.skipped_limit == 5                       # 剩余只计数
        assert len(db.execute(select(CrawlTask)).scalars().all()) == 1   # 不建行

    def test_low_content_page_not_stored(self, db):
        """正文不足门槛的页面不建 document（实测港府跳转页仅 17 字）。"""
        src = self._setup_source(db, code="sd_test")
        listing = (
            "<html><body><a href='/zwgk/redirect.html'>跳转</a>"
            "<a href='/art/2026/a.html'>文章</a></body></html>"
        ).encode("utf-8")
        thin_page = (
            "<html><head><title>山东省商务厅</title></head><body>"
            "<div>政府信息 公开指南 政府信息 公开制度 法定主动 公开内容</div></body></html>"
        ).encode("utf-8")
        assert len("政府信息 公开指南 政府信息 公开制度 法定主动 公开内容") < MIN_CONTENT_CHARS
        fetcher = _FakeFetcher({
            "http://commerce.shandong.gov.cn/": listing,
            "http://commerce.shandong.gov.cn/zwgk/redirect.html": thin_page,
            "http://commerce.shandong.gov.cn/art/2026/a.html": _article_html(
                "山东省商务厅 商务要闻 全省商务工作会议在济南召开", _LONG_ZH
            ),
        })
        stats = sync_source(db, src, settings=_mk_settings(), fetcher=fetcher,
                            sleeper=lambda s: None, resolver=fake_resolver)
        assert stats.new_docs == 1
        tasks = {t.url: t.status for t in db.execute(select(CrawlTask)).scalars()}
        assert tasks["http://commerce.shandong.gov.cn/zwgk/redirect.html"] == "skipped_low_content"


# ---------------------------------------------------------------------------
# 鲁港通 - 栏目/列表页形态判定（实测取证 diag-colpages.log 的真实 URL）
# ---------------------------------------------------------------------------

class TestIsListingPage:
    """黑名单式判定：宁可放过也不可误杀港府形态各异的文档页。"""

    @pytest.mark.parametrize("url", [
        "http://czt.shandong.gov.cn/col/col190914/index.html",   # 实测 sd_czt 栏目页
        "https://www.jinan.gov.cn/col/col2608/index.html",       # 实测 jinan_gov 入口
        "http://edu.shandong.gov.cn/col/col1234/index_1.html",   # 栏目翻页
        "http://edu.shandong.gov.cn/col/col1234/",               # 无 index.html
        "http://kjt.shandong.gov.cn/index.html",                 # 站点首页
        "https://www.wfsfaa.gov.hk/en/index.htm",                # .htm 变体
    ])
    def test_listing_pages_matched(self, url):
        assert is_listing_page(url) is True

    @pytest.mark.parametrize("url", [
        # 实测山东文章页
        "http://czt.shandong.gov.cn/art/2026/8/25/art_10579_10332325.html",
        # 实测济南市系文章页嵌在栏目路径下（probe-cols.log 2026-09-09）：形态是
        # /col/colNNNNN/art/YYYY/art_<uuid>.html，若正则把「在 /col/ 下」单独当作
        # 列表页判据，jinan_gov/jinan_hrss 两个来源将一篇也采不到。
        "https://jnhrss.jinan.gov.cn/col/col18309/art/2026/art_60aea50238d24db9b9b08617192979a0.html",
        "https://jnhrss.jinan.gov.cn/col/col39924/art/2026/art_855123c70a5c4d419d7c246c48cd77ca.html",
        # 实测港府文档页：形态各异且大量无扩展名，白名单会误杀
        "https://www.immd.gov.hk/eng/e-visa.html",
        "https://www.investhk.gov.hk/en/our-clients/five-guys-recipe-for-apac-success/",
        "https://www.info.gov.hk/gia/general/202609/09/P2026090900732.htm",
        "https://www.edb.gov.hk/en/7-learning-goals/primary/default.html",
        "https://www.gov.hk/en/theme/multilanguage/mlp/hindi_residents.htm",
        "https://www.news.gov.hk/eng/2026/09/20260909/20260909_191900_462.html",
        "https://www.policyaddress.gov.hk/",
    ])
    def test_document_pages_not_matched(self, url):
        assert is_listing_page(url) is False


# ---------------------------------------------------------------------------
# 鲁港通 - 标题清洗（实测山东政务站 <title> = 站点名 + 栏目名 + 文章标题）
# ---------------------------------------------------------------------------

class TestCleanTitle:
    ORG = "山东省商务厅"

    def test_shandong_title_format_cleaned(self):
        raw = "山东省商务厅 商务要闻 省商务厅召开创建全国文明单位工作推进会"
        assert clean_title(raw, self.ORG) == "省商务厅召开创建全国文明单位工作推进会"

    def test_underscore_separator_cleaned(self):
        assert clean_title("山东省商务厅_全省商务工作会议在济南召开", self.ORG) == "全省商务工作会议在济南召开"

    def test_english_title_never_split(self):
        # 英文标题自带空格：不含机构名前缀时必须原样返回，绝不按空格切碎
        raw = "CE spotlights HK at Belt-Road Summit"
        assert clean_title(raw, "香港特别行政区政府新闻处") == raw
        assert clean_title(raw, None) == raw

    def test_title_equal_to_organization_kept(self):
        # 标题就是站点名（栏目页）：无可清洗，原样返回
        assert clean_title("山东省商务厅", self.ORG) == "山东省商务厅"

    def test_empty_title_returns_none(self):
        assert clean_title(None, self.ORG) is None
        assert clean_title("   ", self.ORG) is None


# ---------------------------------------------------------------------------
# 鲁港通 - 正文容器提取（实测山东文章页正文在 id="zoom"，外居面包屑/字号控件）
# ---------------------------------------------------------------------------

_SD_ARTICLE_HTML = (
    "<html><head><meta charset='utf-8'>"
    "<title>山东省商务厅 商务要闻 省商务厅召开创建全国文明单位工作推进会</title></head>"
    "<body>"
    "<div class='main'>当前位置：首页 &gt; 新闻动态 &gt; 商务要闻</div>"
    "<div class='bt-article-02'>信息来源：山东省商务厅浏览次数：次字体：【大 中 小】</div>"
    f"<div id='zoom'><p>{_LONG_ZH}</p><div class='inner'><p>附注段落仍然在容器内。</p></div></div>"
    "<div class='main_right'>相关报道：其他文章链接噪声</div>"
    "</body></html>"
).encode("utf-8")


class TestContentSelector:
    ORG = "山东省商务厅"

    def test_selector_extracts_container_only(self):
        out = extract_html(_SD_ARTICLE_HTML, content_selector="#zoom", organization=self.ORG)
        assert out.title == "省商务厅召开创建全国文明单位工作推进会"
        # 容器内正文（含嵌套标签）完整保留
        assert "省商务厅今日发布通知" in out.text
        assert "附注段落仍然在容器内" in out.text
        # 容器外 UI 噪声全部剔除
        assert "当前位置" not in out.text
        assert "浏览次数" not in out.text
        assert "相关报道" not in out.text

    def test_class_selector_supported(self):
        html = (
            "<html><body><div class='nav'>导航噪声文字</div>"
            f"<div class='article content'><p>{_LONG_ZH}</p></div></body></html>"
        ).encode("utf-8")
        out = extract_html(html, content_selector=".content")
        assert "省商务厅今日发布通知" in out.text
        assert "导航噪声文字" not in out.text

    def test_selector_miss_falls_back_to_full_text(self):
        # 站点改版导致容器不存在：回退全文，不能返回空正文
        out = extract_html(_SD_ARTICLE_HTML, content_selector="#nonexistent", organization=self.ORG)
        assert out.text and "省商务厅今日发布通知" in out.text
        assert "当前位置" in out.text      # 全文回退时噪声仍在（优于空正文）

    def test_no_selector_keeps_legacy_behaviour(self):
        out = extract_html(_SD_ARTICLE_HTML, organization=self.ORG)
        assert "当前位置" in out.text
        # 标题清洗不依赖容器选择器
        assert out.title == "省商务厅召开创建全国文明单位工作推进会"
