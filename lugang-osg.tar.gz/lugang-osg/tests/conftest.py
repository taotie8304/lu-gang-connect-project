# 鲁港通 - 测试公共配置：让 PG 专用类型（JSONB/UUID）可在 SQLite 内存库编译，
# 使 models 全套建表可用于导入器/pipeline 集成测试（不发真实网络）。
from sqlalchemy.dialects.postgresql import JSONB, UUID
from sqlalchemy.ext.compiler import compiles


@compiles(JSONB, "sqlite")
def _compile_jsonb_sqlite(type_, compiler, **kw):  # noqa: ANN001
    return "JSON"


@compiles(UUID, "sqlite")
def _compile_uuid_sqlite(type_, compiler, **kw):  # noqa: ANN001
    return "CHAR(36)"
